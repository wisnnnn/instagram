<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['simpan'])) {

    $caption = $_POST['caption'];
    $deskripsi = $_POST['deskripsi'];
    $lokasi = $_POST['lokasi'];
    $gambar = upload(); 
    
    $sql = "INSERT INTO post (gambar,caption,deskripsi,lokasi) VALUES ('$gambar','$caption','$deskripsi','$lokasi')";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("location:index.php?tambah=sukses");
    } else {
        header("location:index.php?tambah=gagal");
    }
}


?>