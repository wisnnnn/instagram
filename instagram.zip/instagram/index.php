<?php
session_start();
if(!isset($_SESSION['login'])){
  header("location:login.php?pesan=login dahulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>    <style>
        .card-img-top {
            transition: transform 0.3s;
        }
        .card-img-top:hover {
            transform: scale(1.2);
        }
    </style>
<title>Story</title>
  </head>
<body>
<div class="responsive">
<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand cargram" href="#">
  <img src="logo/logoo.png" alt="Logo CarGram" class="logo">
  <span class="text" style="color: white;">𝓵𝓪𝓽𝓮𝓼𝓽 𝓼𝓽𝓸𝓻𝔂</span>
</a>
    <style>
.navbar-brand {
  color: #ffffff; /* Warna teks putih */
  text-decoration: none; /* Menghapus garis bawah pada teks */
  display: flex; /* Menggunakan flexbox untuk susunan logo dan teks */
  align-items: center; /* Mengatur vertikal tengah */
}

/* Mengatur gaya untuk elemen .logo (logo) */
.logo {
  width: 40px; /* Lebar logo sesuaikan dengan kebutuhan Anda */
  height: auto; /* Menjaga aspek rasio logo */
  margin-right: 10px; /* Jarak antara logo dan teks */
}

/* Mengatur gaya untuk elemen .text (teks) */
.text {
  font-size: 24px; /* Ukuran font teks */
  font-weight: bold; /* Tebal teks */
  font-family: "Arial", sans-serif; /* Jenis font sesuaikan dengan kebutuhan Anda */
}</style>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#exampleModall">+ Tambah</button> |
 <a href="logout.php"><button class="btn btn-secondary ">Log Out</button></a>

    </div>
  </div>
</nav>    <br><br> <br> <br> <br>

<div class="container">
        <div class="row justify-content-center">
            <?php while ($post = mysqli_fetch_assoc($query)) { ?>
              <center>
                <div class="kotak">
                    <div class="card mt-5 d-inline-block" style="width: 30rem;">
                        <img src="images/<?= $post['gambar'] ?>" alt="" class="card-img-top" alt="">
                        <div class="card-body">
                        <h4 class="card-title"><strong><?= $post['caption'] ?></strong></h4>
                            <p class="card-text"><?= $post['deskripsi'] ?></p>
                            <h6 class="card-text">
                            <i class="fas fa-map-marker"></i> <?= $post['lokasi'] ?>
                            </h6>
                            <style>
                              .card-text {
    text-align: left; /* Teks rata kiri */
}

.card-text::before {
    content: ""; /* Membuat garis transparan */
    display: block;
    height: 1px;
    background-color: rgba(0, 0, 0, 0.1); /* Warna garis transparan */
    margin-top: 10px; /* Jarak antara teks dan garis */
}
                            </style>
           <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><span class="fa fa-edit"></span></button>
                            <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('Apakah Anda yakin ingin menghapus ini?')">
                            <button class="btn btn-danger"><i class="fa fa-trash-can" style="font-size:20px"></i></button></a>
                        </div>
                    </div>
                </div>
        </div>
        </center>

        <!-- modal edit> -->
        <div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">

            <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>   
            </div><div class="container">
            <h3 class="modal-title" id="staticBackdropLabel">Edit Postingan <?=$post['caption']?></h3><br>
            <form action="proses_edit.php" method="post" enctype="multipart/form-data">

                        <input type="hidden" name="no" value="<?=$post['no']?>">
                        <input type="hidden" name="gambar_lama" value="<?=$post['gambar']?>">

                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" class="form-control" id="gambar" name="gambar" value="<?= $post['gambar'] ?>">
                            <img src="images/<?= $post['gambar'] ?>" width="100" alt="" class="mt-2">
                        </div>

                        <div class="form-group">
                            <label for="caption">Judul</label>
                            <input type="text" class="form-control" id="caption" name="caption" autocomplete="off" value="<?=$post['caption']?>" required>
                        </div>

                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="5" autocomplete="off" required><?=$post['deskripsi']?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="lokasi">Lokasi</label>
                            <input type="text" class="form-control" id="lokasi" name="lokasi" autocomplete="off" value="<?=$post['lokasi']?>" required>
                        </div><br>

                        <button type="submit" class="btn btn-primary" name="update">Edit</button>
                    </form>
        </div></div>
        </div>
        </div>    
        <?php } ?>

  
        
        <div class="modal fade" id="exampleModall" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header btn btn-dark">
      <h5 class="modal-title " id="exampleModalLabel">Form Tambah Postingan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="card-body">
        <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
       <label for="gambar">Gambar</label>
        <input type="file" class="form-control" id="gambar" name="gambar" autocomplete="off" required>
        </div>

        <div class="form-group">
       <label for="caption">Judul</label>
        <input type="text" class="form-control" id="caption" name="caption" autocomplete="off" required>
        </div>

        <div class="form-group">
        <label for="deskripsi">Deskripsi</label>
         <textarea class="form-control" id="deskripsi" name="deskripsi" rows="5" autocomplete="off" required></textarea>
        </div>

        <div class="form-group">
        <label for="lokasi">Lokasi</label>
        <input type="text" class="form-control" id="lokasi" name="lokasi" autocomplete="off" required><br>
        </div>

        <button type="submit" class="btn btn-primary" name="simpan">Tambah</button>
  </form>

        </div>
      </div>
    </div>
  </div>
  
</body>
</html>
